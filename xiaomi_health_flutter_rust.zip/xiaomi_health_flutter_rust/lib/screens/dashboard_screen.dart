import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/report_record.dart';
import '../services/rust_bridge.dart';
import '../widgets/charts_section.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final RustBugreportService _service = RustBugreportService();
  late List<DeviceHealthReport> _reports;
  late DeviceHealthReport _selectedReport;

  @override
  void initState() {
    super.initState();
    _reports = RustBugreportService.initialSampleReports();
    _selectedReport = _reports.last;
  }

  Future<void> _pickAndAnalyzeZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      dialogTitle: 'Chọn file bugreport-*.zip từ /MIUI/debug_log/',
    );
    if (result != null && result.files.single.path != null) {
      final path = result.files.single.path!;
      final rep = await _service.importZipFile(path);
      setState(() {
        _reports.add(rep);
        _selectedReport = rep;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = _selectedReport;
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        title: Text('${r.deviceModel} • ${r.osVersion}'),
        actions: [
          FilledButton.icon(
            onPressed: _pickAndAnalyzeZip,
            icon: const Icon(Icons.folder_zip_outlined),
            label: const Text('Nhập Bugreport ZIP'),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildMetadataBanner(r),
            const SizedBox(height: 16),
            _buildKpiGrid(r),
            const SizedBox(height: 20),
            BatteryComparisonCharts(reports: _reports),
            const SizedBox(height: 20),
            _buildHistoryComparisonTable(),
          ],
        ),
      ),
    );
  }

  Widget _buildMetadataBanner(DeviceHealthReport r) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Wrap(
        spacing: 24,
        runSpacing: 8,
        children: [
          Text('📦 File tổng: ${r.outerZipName}', style: const TextStyle(color: Colors.white70)),
          Text('🗜️ File con: ${r.innerZipName}', style: const TextStyle(color: Colors.white70)),
          Text('📅 Ngày ghi log (Report Date): ${r.reportDate}',
              style: const TextStyle(color: Color(0xFF38BDF8), fontWeight: FontWeight.w600)),
          Text('📥 Ngày nhận kiểm tra (Received Date): ${r.receivedDate}',
              style: const TextStyle(color: Color(0xFF34D399), fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildKpiGrid(DeviceHealthReport r) {
    return Wrap(
      spacing: 16,
      runSpacing: 16,
      children: [
        _kpiCard('Sức khỏe Pin (SoH)', '${r.healthPercent}%',
            '${r.fullChargeMah} / ${r.designCapacityMah} mAh (Chai ${r.degradationPercent.toStringAsFixed(1)}%)'),
        _kpiCard('Chu kỳ sạc (Cycles)', '${r.cycleCount} lần',
            'Điện áp: ${r.voltageMv} mV • Nhiệt độ: ${r.batteryTempC}°C'),
        _kpiCard('Ổ cứng UFS 4.0 (${r.storageGb}GB)', 'Hao mòn 0-10%',
            'PreEOL: 0x0${r.preEolInfo} • LifeA/B: 0x0${r.lifeTimeEstA}/0x0${r.lifeTimeEstB} • Lỗi: ${r.ufsLinkErrors}'),
        _kpiCard('Độ ổn định & Sóng 5G', 'Uptime ${r.uptimeStr}',
            'Modem reset: ${r.modemCrashCount} lần • App crash: ${r.tombstoneCount} (${r.topCrashingProcess})'),
      ],
    );
  }

  Widget _kpiCard(String title, String value, String sub) {
    return Container(
      width: 300,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white60, fontSize: 13)),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildHistoryComparisonTable() {
    return Card(
      color: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lịch sử các lần kiểm tra đã lưu (So sánh giữa các ngày)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Ngày ghi log')),
                  DataColumn(label: Text('Ngày nhận')),
                  DataColumn(label: Text('Chu kỳ sạc')),
                  DataColumn(label: Text('Dung lượng thực')),
                  DataColumn(label: Text('Sức khỏe Pin')),
                  DataColumn(label: Text('Nhiệt độ Pin/Vỏ')),
                  DataColumn(label: Text('UFS Wear')),
                  DataColumn(label: Text('Modem / App Crash')),
                ],
                rows: _reports.map((rep) {
                  return DataRow(
                    selected: rep.id == _selectedReport.id,
                    onSelectChanged: (_) => setState(() => _selectedReport = rep),
                    cells: [
                      DataCell(Text(rep.reportDate)),
                      DataCell(Text(rep.receivedDate)),
                      DataCell(Text('${rep.cycleCount} vòng')),
                      DataCell(Text('${rep.fullChargeMah} mAh')),
                      DataCell(Text('${rep.healthPercent}%')),
                      DataCell(Text('${rep.batteryTempC}°C / ${rep.skinTempC}°C')),
                      DataCell(Text('0x0${rep.lifeTimeEstA} (0-10%)')),
                      DataCell(Text('${rep.modemCrashCount} modem / ${rep.tombstoneCount} crash')),
                    ],
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
