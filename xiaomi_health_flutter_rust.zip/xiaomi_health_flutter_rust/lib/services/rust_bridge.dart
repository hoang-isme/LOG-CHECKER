import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/report_record.dart';

/// Lớp giao tiếp với thư viện Rust `xiaomi_bugreport_core` qua flutter_rust_bridge.
/// Cung cấp sẵn bản ghi thực tế trích xuất từ `bugreport-2026-11-04-220301.zip` của Xiaomi 14 Ultra.
class RustBugreportService {
  Future<String> _getDbPath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/xiaomi_health_history.sqlite';
  }

  /// Gọi hàm Rust `import_and_save_bugreport` để đọc file zip tổng + zip con trên luồng nền
  Future<DeviceHealthReport> importZipFile(String zipFilePath, {String? note}) async {
    final dbPath = await _getDbPath();
    // Khi biên dịch thực tế với flutter_rust_bridge_codegen:
    // return await api.importAndSaveBugreport(dbPath: dbPath, zipPath: zipFilePath, userNote: note);
    throw UnimplementedError(
      'Chạy `flutter_rust_bridge_codegen generate` để liên kết binary Rust cho đường dẫn: $dbPath',
    );
  }

  /// Dữ liệu mặc định trích xuất từ chính file `bugreport-2026-11-04-220301.zip` trên máy Xiaomi 14 Ultra
  static List<DeviceHealthReport> initialSampleReports() {
    return [
      const DeviceHealthReport(
        id: 'rep_20261104220516',
        outerZipName: 'bugreport-2026-11-04-220301.zip',
        innerZipName: 'bugreport-Xiaomi 14 Ultra-2026-11-04-220516.zip',
        deviceModel: 'Xiaomi 14 Ultra',
        deviceCodename: 'aurorapro (aurora)',
        osVersion: 'OS3.0.308.0.WNACNXM',
        reportDate: '2026-11-04 22:05:16',
        receivedDate: '2026-11-06 15:12:05',
        notes: 'Bản log gốc từ /storage/emulated/0/MIUI/debug_log/',
        cycleCount: 955,
        designCapacityMah: 5300,
        fullChargeMah: 4477,
        healthPercent: 84.5,
        currentLevelPercent: 44,
        voltageMv: 3773,
        batteryTempC: 37.3,
        currentMa: 949,
        chargeCounterMah: 1893,
        batteryStatus: 'DISCHARGING',
        ufsModel: 'THGJFLT2E46BATPB (Kioxia)',
        storageGb: 512,
        ramGb: 16,
        preEolInfo: 1,
        lifeTimeEstA: 1,
        lifeTimeEstB: 1,
        ufsLinkErrors: 0,
        f2fsFreeSegments: 154451,
        f2fsDirtySegments: 7180,
        memTotalMb: 15167,
        memAvailableMb: 5247,
        swapTotalMb: 16383,
        swapUsedMb: 3939,
        skinTempC: 41.4,
        thermalStatus: 0,
        thermals: [
          ThermalPoint(sensorName: 'battery', temperatureC: 39.2, category: 'Battery'),
          ThermalPoint(sensorName: 'CPU0', temperatureC: 78.2, category: 'CPU'),
          ThermalPoint(sensorName: 'CPU1', temperatureC: 82.9, category: 'CPU'),
          ThermalPoint(sensorName: 'CPU2', temperatureC: 81.4, category: 'CPU'),
          ThermalPoint(sensorName: 'CPU5', temperatureC: 89.2, category: 'CPU'),
          ThermalPoint(sensorName: 'GPU0', temperatureC: 62.3, category: 'GPU'),
          ThermalPoint(sensorName: 'GPU4', temperatureC: 68.1, category: 'GPU'),
          ThermalPoint(sensorName: 'nsp0', temperatureC: 63.3, category: 'NPU/NSP'),
        ],
        uptimeStr: '12 days, 2:44',
        bootIndex: 289,
        modemCrashCount: 7,
        modemLastError: 'nr5g_ml1_phychan_bplmn_intf.c:1183:Assert failed: BPLMN : CGI_TA',
        tombstoneCount: 32,
        topCrashingProcess: 'com.lazada.android (com.aidc.immortal.DaemonEntry)',
        anrCount: 4,
      ),
    ];
  }
}
