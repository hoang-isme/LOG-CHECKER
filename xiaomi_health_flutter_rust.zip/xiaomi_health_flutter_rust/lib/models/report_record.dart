class ThermalPoint {
  final String sensorName;
  final double temperatureC;
  final String category;

  const ThermalPoint({
    required this.sensorName,
    required this.temperatureC,
    required this.category,
  });

  factory ThermalPoint.fromJson(Map<String, dynamic> json) => ThermalPoint(
        sensorName: json['sensor_name'] as String,
        temperatureC: (json['temperature_c'] as num).toDouble(),
        category: json['category'] as String,
      );
}

class DeviceHealthReport {
  final String id;
  final String outerZipName;
  final String innerZipName;
  final String deviceModel;
  final String deviceCodename;
  final String osVersion;
  final String reportDate;   // Ngày ghi trong file log
  final String receivedDate; // Ngày nhận / kiểm tra trong app
  final String notes;

  // Thông số Pin
  final int cycleCount;
  final int designCapacityMah;
  final int fullChargeMah;
  final double healthPercent;
  final int currentLevelPercent;
  final int voltageMv;
  final double batteryTempC;
  final int currentMa;
  final int chargeCounterMah;
  final String batteryStatus;

  // Thông số Ổ cứng UFS & RAM
  final String ufsModel;
  final int storageGb;
  final int ramGb;
  final int preEolInfo;
  final int lifeTimeEstA;
  final int lifeTimeEstB;
  final int ufsLinkErrors;
  final int f2fsFreeSegments;
  final int f2fsDirtySegments;
  final int memTotalMb;
  final int memAvailableMb;
  final int swapTotalMb;
  final int swapUsedMb;

  // Nhiệt độ & Độ ổn định
  final double skinTempC;
  final int thermalStatus;
  final List<ThermalPoint> thermals;
  final String uptimeStr;
  final int bootIndex;
  final int modemCrashCount;
  final String modemLastError;
  final int tombstoneCount;
  final String topCrashingProcess;
  final int anrCount;

  const DeviceHealthReport({
    required this.id,
    required this.outerZipName,
    required this.innerZipName,
    required this.deviceModel,
    required this.deviceCodename,
    required this.osVersion,
    required this.reportDate,
    required this.receivedDate,
    required this.notes,
    required this.cycleCount,
    required this.designCapacityMah,
    required this.fullChargeMah,
    required this.healthPercent,
    required this.currentLevelPercent,
    required this.voltageMv,
    required this.batteryTempC,
    required this.currentMa,
    required this.chargeCounterMah,
    required this.batteryStatus,
    required this.ufsModel,
    required this.storageGb,
    required this.ramGb,
    required this.preEolInfo,
    required this.lifeTimeEstA,
    required this.lifeTimeEstB,
    required this.ufsLinkErrors,
    required this.f2fsFreeSegments,
    required this.f2fsDirtySegments,
    required this.memTotalMb,
    required this.memAvailableMb,
    required this.swapTotalMb,
    required this.swapUsedMb,
    required this.skinTempC,
    required this.thermalStatus,
    required this.thermals,
    required this.uptimeStr,
    required this.bootIndex,
    required this.modemCrashCount,
    required this.modemLastError,
    required this.tombstoneCount,
    required this.topCrashingProcess,
    required this.anrCount,
  });

  double get degradationMah => (designCapacityMah - fullChargeMah).toDouble();
  double get degradationPercent => 100.0 - healthPercent;
}
