import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const XiaomiHealthInspectorApp());
}

class XiaomiHealthInspectorApp extends StatelessWidget {
  const XiaomiHealthInspectorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Xiaomi Bugreport Health Analyzer (Rust + Flutter)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const DashboardScreen(),
    );
  }
}
