import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/report_record.dart';

class BatteryComparisonCharts extends StatelessWidget {
  final List<DeviceHealthReport> reports;

  const BatteryComparisonCharts({super.key, required this.reports});

  @override
  Widget build(BuildContext context) {
    final sorted = List<DeviceHealthReport>.from(reports)
      ..sort((a, b) => a.reportDate.compareTo(b.reportDate));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildCapacityTrendCard(context, sorted),
        const SizedBox(height: 16),
        _buildThermalBarCard(context, sorted.last),
      ],
    );
  }

  Widget _buildCapacityTrendCard(BuildContext context, List<DeviceHealthReport> sorted) {
    return Card(
      elevation: 0,
      color: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Biểu đồ so sánh Dung lượng Pin thực tế (mAh) & Chu kỳ sạc qua các ngày',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 6),
            const Text(
              'So sánh giữa các bản ghi theo Ngày ghi log (Report Date) để theo dõi tốc độ chai pin',
              style: TextStyle(fontSize: 13, color: Colors.white60),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 240,
              child: LineChart(
                LineChartData(
                  minY: 3500,
                  maxY: 5400,
                  gridData: const FlGridData(show: true, drawVerticalLine: false),
                  titlesData: FlTitlesData(
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          final idx = value.toInt();
                          if (idx < 0 || idx >= sorted.length) return const SizedBox.shrink();
                          final dateShort = sorted[idx].reportDate.substring(0, 10);
                          return Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              '$dateShort\n(${sorted[idx].cycleCount} cyc)',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 11, color: Colors.white70),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: List.generate(
                        sorted.length,
                        (i) => FlSpot(i.toDouble(), sorted[i].fullChargeMah.toDouble()),
                      ),
                      isCurved: true,
                      color: const Color(0xFF38BDF8),
                      barWidth: 3,
                      dotData: const FlDotData(show: true),
                      belowBarData: BarAreaData(
                        show: true,
                        color: const Color(0xFF38BDF8).withOpacity(0.15),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThermalBarCard(BuildContext context, DeviceHealthReport latest) {
    return Card(
      elevation: 0,
      color: const Color(0xFF1E293B),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Phân bổ nhiệt độ phần cứng (${latest.reportDate})',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  maxY: 105,
                  barGroups: List.generate(latest.thermals.length, (i) {
                    final item = latest.thermals[i];
                    return BarChartGroupData(
                      x: i,
                      barRods: [
                        BarChartRodData(
                          toY: item.temperatureC,
                          width: 18,
                          borderRadius: BorderRadius.circular(4),
                          color: item.temperatureC > 80
                              ? const Color(0xFFF97316)
                              : const Color(0xFF10B981),
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
