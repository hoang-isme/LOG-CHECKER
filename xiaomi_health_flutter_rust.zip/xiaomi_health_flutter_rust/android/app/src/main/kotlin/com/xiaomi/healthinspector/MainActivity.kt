package com.xiaomi.healthinspector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
