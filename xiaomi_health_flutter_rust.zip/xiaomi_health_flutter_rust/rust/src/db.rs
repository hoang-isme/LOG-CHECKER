use crate::models::DeviceHealthReport;
use anyhow::Result;
use rusqlite::{params, Connection};

pub struct HealthDatabase {
    conn: Connection,
}

impl HealthDatabase {
    pub fn open(db_path: &str) -> Result<Self> {
        let conn = Connection::open(db_path)?;
        conn.execute(
            "CREATE TABLE IF NOT EXISTS health_reports (
                id TEXT PRIMARY KEY,
                report_date TEXT NOT NULL,
                received_date TEXT NOT NULL,
                outer_zip_name TEXT NOT NULL,
                cycle_count INTEGER NOT NULL,
                full_charge_mah INTEGER NOT NULL,
                health_percent REAL NOT NULL,
                battery_temp_c REAL NOT NULL,
                skin_temp_c REAL NOT NULL,
                ufs_wear_a INTEGER NOT NULL,
                modem_crashes INTEGER NOT NULL,
                tombstones INTEGER NOT NULL,
                raw_json TEXT NOT NULL
            )",
            [],
        )?;
        Ok(Self { conn })
    }

    /// Lưu báo cáo mới hoặc cập nhật nếu trùng thời điểm xuất log
    pub fn save_report(&self, report: &DeviceHealthReport) -> Result<()> {
        let raw_json = serde_json::to_string(report)?;
        self.conn.execute(
            "INSERT OR REPLACE INTO health_reports (
                id, report_date, received_date, outer_zip_name,
                cycle_count, full_charge_mah, health_percent,
                battery_temp_c, skin_temp_c, ufs_wear_a,
                modem_crashes, tombstones, raw_json
            ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13)",
            params![
                report.id,
                report.report_date,
                report.received_date,
                report.outer_zip_name,
                report.battery.cycle_count,
                report.battery.full_charge_mah,
                report.battery.health_percent,
                report.battery.temperature_c,
                report.skin_temp_c,
                report.storage.life_time_est_a,
                report.stability.modem_crash_count,
                report.stability.tombstone_count,
                raw_json,
            ],
        )?;
        Ok(())
    }

    /// Lấy toàn bộ lịch sử đã lưu theo thứ tự thời gian báo cáo tăng dần để vẽ biểu đồ so sánh
    pub fn list_reports(&self) -> Result<Vec<DeviceHealthReport>> {
        let mut stmt = self
            .conn
            .prepare("SELECT raw_json FROM health_reports ORDER BY report_date ASC")?;
        let rows = stmt.query_map([], |row| {
            let json_str: String = row.get(0)?;
            Ok(json_str)
        })?;

        let mut reports = Vec::new();
        for json_res in rows {
            if let Ok(json_str) = json_res {
                if let Ok(rep) = serde_json::from_str::<DeviceHealthReport>(&json_str) {
                    reports.push(rep);
                }
            }
        }
        Ok(reports)
    }

    pub fn delete_report(&self, id: &str) -> Result<()> {
        self.conn
            .execute("DELETE FROM health_reports WHERE id = ?1", params![id])?;
        Ok(())
    }
}
