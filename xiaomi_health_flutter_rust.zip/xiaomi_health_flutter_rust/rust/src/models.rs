use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermalPoint {
    pub sensor_name: String,
    pub temperature_c: f64,
    pub category: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatteryStats {
    pub cycle_count: u32,
    pub design_capacity_mah: u32,
    pub full_charge_mah: u32,
    pub health_percent: f64,
    pub current_level_percent: u32,
    pub voltage_mv: u32,
    pub temperature_c: f64,
    pub current_ma: i32,
    pub charge_counter_mah: u32,
    pub status: String,
    pub health_status: String,
    pub technology: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UfsStorageHealth {
    pub chip_model: String,
    pub ufs_version: String,
    pub capacity_gb: u32,
    pub ram_gb: u32,
    pub pre_eol_info: u8,
    pub life_time_est_a: u8,
    pub life_time_est_b: u8,
    pub link_errors_total: u32,
    pub f2fs_free_segments: u32,
    pub f2fs_dirty_segments: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryStats {
    pub mem_total_mb: u32,
    pub mem_available_mb: u32,
    pub swap_total_mb: u32,
    pub swap_used_mb: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilityStats {
    pub uptime_str: String,
    pub boot_index: u32,
    pub oops_index: u32,
    pub last_powerup_reason: String,
    pub last_poweroff_reason: String,
    pub modem_crash_count: u32,
    pub modem_last_error: String,
    pub tombstone_count: u32,
    pub top_crashing_process: String,
    pub anr_count: u32,
    pub anr_processes: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceHealthReport {
    pub id: String,
    pub outer_zip_name: String,
    pub inner_zip_name: String,
    pub device_model: String,
    pub device_codename: String,
    pub os_version: String,
    /// Thời điểm máy xuất file log (trích từ tên file / header trong bugreport)
    pub report_date: String,
    /// Thời điểm người dùng nhập / lưu báo cáo vào ứng dụng để theo dõi
    pub received_date: String,
    pub notes: String,
    pub battery: BatteryStats,
    pub storage: UfsStorageHealth,
    pub memory: MemoryStats,
    pub thermals: Vec<ThermalPoint>,
    pub skin_temp_c: f64,
    pub thermal_status: u32,
    pub stability: StabilityStats,
}
