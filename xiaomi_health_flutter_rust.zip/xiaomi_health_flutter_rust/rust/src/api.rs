use crate::db::HealthDatabase;
use crate::models::DeviceHealthReport;
use crate::parser::parse_xiaomi_bugreport_zip;
use anyhow::Result;
use std::fs;
use std::path::Path;

/// Mặc định trên điện thoại Xiaomi (HyperOS / MIUI)
pub const MIUI_DEBUG_LOG_DIR: &str = "/storage/emulated/0/MIUI/debug_log";

/// Tự động quét thư mục `/storage/emulated/0/MIUI/debug_log/` trên điện thoại Xiaomi
/// để tìm toàn bộ các file `bugreport-*.zip` mới nhất và nhập vào SQLite.
pub fn scan_miui_debug_log_folder(db_path: String, custom_dir: Option<String>) -> Result<Vec<DeviceHealthReport>> {
    let target_dir = custom_dir.unwrap_or_else(|| MIUI_DEBUG_LOG_DIR.to_string());
    let dir_path = Path::new(&target_dir);
    let db = HealthDatabase::open(&db_path)?;

    if dir_path.exists() && dir_path.is_dir() {
        for entry in fs::read_dir(dir_path)? {
            if let Ok(entry) = entry {
                let path = entry.path();
                if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                    if name.starts_with("bugreport-") && name.ends_with(".zip") {
                        if let Some(path_str) = path.to_str() {
                            if let Ok(report) = parse_xiaomi_bugreport_zip(path_str, Some("Quét tự động từ /MIUI/debug_log/".to_string())) {
                                let _ = db.save_report(&report);
                            }
                        }
                    }
                }
            }
        }
    }
    db.list_reports()
}

/// Hàm FFI gọi từ Flutter: Chọn file ZIP tổng (/MIUI/debug_log/bugreport-*.zip),
/// bóc tách thông số và tự động lưu vào SQLite kèm ngày ghi (report_date) & ngày nhận (received_date).
pub fn import_and_save_bugreport(
    db_path: String,
    zip_path: String,
    user_note: Option<String>,
) -> Result<DeviceHealthReport> {
    let report = parse_xiaomi_bugreport_zip(&zip_path, user_note)?;
    let db = HealthDatabase::open(&db_path)?;
    db.save_report(&report)?;
    Ok(report)
}

/// Lấy danh sách tất cả các lần kiểm tra đã lưu để vẽ biểu đồ so sánh theo ngày
pub fn get_saved_reports(db_path: String) -> Result<Vec<DeviceHealthReport>> {
    let db = HealthDatabase::open(&db_path)?;
    db.list_reports()
}

/// Xóa một bản ghi lịch sử theo ID
pub fn remove_saved_report(db_path: String, report_id: String) -> Result<Vec<DeviceHealthReport>> {
    let db = HealthDatabase::open(&db_path)?;
    db.delete_report(&report_id)?;
    db.list_reports()
}
