# Xiaomi Bugreport Health Analyzer — Android APK (Rust + Flutter)

Ứng dụng Android chạy trực tiếp trên điện thoại Xiaomi (HyperOS / MIUI), tự động truy cập đường dẫn `/storage/emulated/0/MIUI/debug_log/` để tìm gói `bugreport-*.zip`, giải nén ngầm file zip con bên trong (`bugreport-Xiaomi 14 Ultra-*.zip`) bằng nhân **Rust (`aarch64-linux-android`)** và vẽ biểu đồ theo dõi độ chai pin qua các ngày trên **Flutter**.

## Cách xuất file `.apk` cài trực tiếp lên điện thoại Xiaomi

### Cách 1: Build APK tự động trên đám mây bằng GitHub Actions (Không cần cài SDK trên máy tính)
1. Tạo 1 repository mới trên GitHub và đẩy toàn bộ thư mục giải nén này lên.
2. Vào tab **Actions** trên GitHub -> chọn workflow **Build Xiaomi Health Inspector APK (Rust + Flutter)** -> bấm **Run workflow**.
3. Sau khoảng 3 phút, tải file **`Xiaomi-Health-Inspector-arm64-APK` (`app-release.apk`)** về điện thoại Xiaomi và cài đặt.

### Cách 2: Build APK trên máy tính (Windows / macOS / Linux)
```bash
# 1. Thêm target Android arm64 cho Rust và cài cargo-ndk
rustup target add aarch64-linux-android
cargo install cargo-ndk

# 2. Biên dịch thư viện Rust sang .so cho chip Snapdragon 8 Gen 3 (arm64-v8a)
cd rust
cargo ndk -t arm64-v8a -o ../android/app/src/main/jniLibs build --release
cd ..

# 3. Đóng gói file APK
flutter pub get
flutter build apk --release --target-platform android-arm64
```
File APK xuất ra nằm tại: `build/app/outputs/flutter-apk/app-release.apk`.

## Quyền truy cập trên Xiaomi (HyperOS)
Khi mở app lần đầu trên Xiaomi 14 Ultra:
1. Bấm nút **"Quét tự động `/MIUI/debug_log/`"**, ứng dụng sẽ yêu cầu quyền `MANAGE_EXTERNAL_STORAGE` (Quyền truy cập tất cả tệp).
2. Bật công tắc cấp quyền cho **Mi Health Log**, app sẽ tự động đọc tất cả các file `bugreport-*.zip` trong `/storage/emulated/0/MIUI/debug_log/`, bóc tách file zip con bên trong và lưu vào SQLite kèm **Ngày ghi log (`report_date`)** và **Ngày kiểm tra (`received_date`)**.
